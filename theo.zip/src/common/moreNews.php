<section id="moreNews">
    <h2 class="mb-2 ml-9 mt-3">Plus de news...</h2>

    <div class="moreNews">
        <div class="cardNews moreNews-row-item">
            <div class="v2"></div>
            <h2>The last of us: Un remaque en préparation ?</h2>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident itaque voluptatum soluta nostrum similique commodi at quae aliquid dolorum? Dicta alias ipsa sit ea necessitatibus ipsum, impedit excepturi quis numquam illo quibusdam aspernatur voluptatem tempora fugiat eos neque dignissimos nihil eligendi aut repudiandae itaque recusandae? Tempora autem ex iste laboriosam.</p>
            <span>+PLUS</span>
        </div>
        <div class="cardNews moreNews-row-item">
            <div class="v2"></div>
            <h2>The last of us: Un remaque en préparation ?</h2>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident itaque voluptatum soluta nostrum similique commodi at quae aliquid dolorum? Dicta alias ipsa sit ea necessitatibus ipsum, impedit excepturi quis numquam illo quibusdam aspernatur voluptatem tempora fugiat eos neque dignissimos nihil eligendi aut repudiandae itaque recusandae? Tempora autem ex iste laboriosam.</p>
            <span>+PLUS</span>
        </div>
        <div class="cardNews moreNews-row-item">
            <div class="v2"></div>
            <h2>The last of us: Un remaque en préparation ?</h2>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident itaque voluptatum soluta nostrum similique commodi at quae aliquid dolorum? Dicta alias ipsa sit ea necessitatibus ipsum, impedit excepturi quis numquam illo quibusdam aspernatur voluptatem tempora fugiat eos neque dignissimos nihil eligendi aut repudiandae itaque recusandae? Tempora autem ex iste laboriosam.</p>
            <span>+PLUS</span>
        </div>
        <div class="cardNews moreNews-row-item">
            <div class="v2"></div>
            <h2>The last of us: Un remaque en préparation ?</h2>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident itaque voluptatum soluta nostrum similique commodi at quae aliquid dolorum? Dicta alias ipsa sit ea necessitatibus ipsum, impedit excepturi quis numquam illo quibusdam aspernatur voluptatem tempora fugiat eos neque dignissimos nihil eligendi aut repudiandae itaque recusandae? Tempora autem ex iste laboriosam.</p>
            <span>+PLUS</span>
        </div>
        <div class="cardNews moreNews-row-item">
            <div class="v2"></div>
            <h2>The last of us: Un remaque en préparation ?</h2>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident itaque voluptatum soluta nostrum similique commodi at quae aliquid dolorum? Dicta alias ipsa sit ea necessitatibus ipsum, impedit excepturi quis numquam illo quibusdam aspernatur voluptatem tempora fugiat eos neque dignissimos nihil eligendi aut repudiandae itaque recusandae? Tempora autem ex iste laboriosam.</p>
            <span>+PLUS</span>
        </div>
        <div class="cardNews moreNews-row-item">
            <div class="v2"></div>
            <h2>The last of us: Un remaque en préparation ?</h2>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident itaque voluptatum soluta nostrum similique commodi at quae aliquid dolorum? Dicta alias ipsa sit ea necessitatibus ipsum, impedit excepturi quis numquam illo quibusdam aspernatur voluptatem tempora fugiat eos neque dignissimos nihil eligendi aut repudiandae itaque recusandae? Tempora autem ex iste laboriosam.</p>
            <span>+PLUS</span>
        </div>
    </div>

</section>