<?php
$titre = "BELGIUM VIDEO-GAMING";
    require "../../src/common/template.php";
?>