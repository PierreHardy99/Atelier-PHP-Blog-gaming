<?php
$titre = "BELGIUM VIDEO-GAMING";
    require "./src/common/template.php";
    require "./src/common/news.php";
    require "./src/common/moreNews.php";
    require "./src/common/footer.php";
?>